import requests
from bs4 import BeautifulSoup
import re


def get_last_number_of_page():
    query = 'https://tioanime.com/directorio'
    response = requests.get(query, headers={'User-Agent': 'XYZ/3.0'}).text
    web_parser = BeautifulSoup(response, 'html.parser')
    last_number_page = web_parser.find_all(
        'a', {'class': 'page-link'})[-2].get_text()
    return int(last_number_page)


def get_animes_titles(page):
    articles = get_articles_animes(page)
    list_anime_titles = [{'title': article.h3.text} for article in articles]
    return list_anime_titles


def get_animes_urls(page):
    articles = get_articles_animes(page)
    list_anime_urls = [{'url_anime': 'https://tioanime.com' + article.a.get_attribute_list('href')[0]} for article in articles]
    return list_anime_urls


def get_articles_animes(page):
    articles = []

    query = f'https://tioanime.com/directorio?p={page}'
    response = requests.get(query, headers={'User-Agent': 'XYZ/3.0'}).text
    web_parser = BeautifulSoup(response, 'html.parser')
    total_animes_in_page = len(
        web_parser.find_all('article', {'class': 'anime'}))

    for j in range(0, total_animes_in_page):
        articles.insert(j, web_parser.find_all(
            'article', {'class': 'anime'})[j])

    return articles


def get_animes(page):

    list_animes = []
    articles = get_articles_animes(page)

    for article in articles:
        list_animes.append({
            'title': article.h3.text,
            'url_anime': 'https://tioanime.com' + article.a.get_attribute_list('href')[0],
            'thumb': 'https://tioanime.com' + article.div.img.get_attribute_list('src')[0]
        })

    for anime in list_animes:
        anime.update({
            'synopsis': get_synopsis_anime(anime.get('url_anime'))
        })

    return list_animes


def search_anime(name):
    list_search = []
    list_articles = []
    query = 'https://tioanime.com/directorio?q=' + name.replace(' ', '+')
    response = requests.get(query, headers={'User-Agent': 'XYZ/3.0'}).text
    web_parser = BeautifulSoup(response, 'html.parser')
    articles = web_parser.find_all('article', {'class': 'anime'})

    for j, article in enumerate(articles):
        list_articles.insert(j, web_parser.find_all(
            'article', {'class': 'anime'})[j])

    for article in articles:
        list_search.append({'title': article.h3.text,
                            'link': 'https://tioanime.com' + article.a.get_attribute_list('href')[0],
                            'thumb': 'https://tioanime.com' + article.div.img.get_attribute_list('src')[0]
                            })
    return list_search


def get_number_of_episodes(url_anime):
    response = requests.get(url_anime, headers={'User-Agent': 'XYZ/3.0'}).text
    season_parser = BeautifulSoup(response, 'html.parser')
    regex1 = re.compile(
        'var episodes = (\[[\d,]*\])', re.MULTILINE | re.DOTALL)
    script = season_parser.find('script', text=regex1)
    regex2 = re.compile('(\[[\d,]*\])', re.MULTILINE | re.DOTALL)
    list_nums_episodes = regex2.search(script.string).group().replace(
        '[', '').replace(']', '').split(',')
    new_list_episodes = [int(num_episode)
                         for num_episode in list_nums_episodes]
    number_of_episodes = sorted(new_list_episodes)
    return number_of_episodes


def get_synopsis_anime(url_anime):
    response = requests.get(url_anime, headers={'User-Agent': 'XYZ/3.0'}).text
    html_parser = BeautifulSoup(response, 'html.parser')
    p = html_parser.find('p', {'class': 'sinopsis'})
    synopsis = p.text.strip('\n')
    return synopsis


def get_urls_streams_episodes(url_anime, provider):

    number_of_episodes = get_number_of_episodes(url_anime)
    episode_format = url_anime.replace('/anime/', '/ver/')
    list_urls_streams = []

    for i, num_episode in enumerate(number_of_episodes):

        episode_url = episode_format + '-' + str(num_episode)
        response = requests.get(episode_url, headers={'User-Agent': 'XYZ/3.0'}).text
        episode_parser = BeautifulSoup(response, 'html.parser')

        if provider == 'fembed':

            regex1 = re.compile(r'www.fembed.com\\/v\\/[a-z0-9-]*', re.MULTILINE | re.DOTALL)
            script = episode_parser.find('script', text=regex1)
            url_parsed1 = regex1.search(script.string).group()
            regex2 = re.compile(r'[a-z0-9-]*$', re.MULTILINE | re.DOTALL)
            url_parsed2 = regex2.search(url_parsed1).group()
            list_urls_streams.insert(i, {
                'episode': num_episode,
                'video': f'https://www.fembed.com/v/{url_parsed2}'
            })

        elif provider == 'orku':

            regex1 = re.compile(r'ok.ru\\/videoembed\\/(\d)*', re.MULTILINE | re.DOTALL)
            script = episode_parser.find('script', text=regex1)
            url_parsed1 = regex1.search(script.string).group()
            regex2 = re.compile(r'(\d)*$', re.MULTILINE | re.DOTALL)
            url_parsed2 = regex2.search(url_parsed1).group()
            list_urls_streams.insert(i, {
                'episode': num_episode,
                'video': f'https://ok.ru/videoembed/{url_parsed2}'
            })

        elif provider == 'yourupload':

            regex1 = re.compile(r'yourupload.com\\/embed\\/[A-Za-z0-9]*', re.MULTILINE | re.DOTALL)
            script = episode_parser.find('script', text=regex1)
            url_parsed1 = regex1.search(script.string).group()
            regex2 = re.compile(r'[A-Za-z0-9]*$', re.MULTILINE | re.DOTALL)
            url_parsed2 = regex2.search(url_parsed1).group()
            list_urls_streams.insert(i, {
                'episode': num_episode,
                'video': f'https://www.yourupload.com/embed/{url_parsed2}'
            })

        elif provider == 'maru':

            regex1 = re.compile(r'my.mail.ru\\/video\\/embed\\/[a-z0-9#]*', re.MULTILINE | re.DOTALL)
            script = episode_parser.find('script', text=regex1)
            url_parsed1 = regex1.search(script.string).group()
            regex2 = re.compile(r'[a-z0-9#]*$', re.MULTILINE | re.DOTALL)
            url_parsed2 = regex2.search(url_parsed1).group()
            list_urls_streams.insert(i, {
                'episode': num_episode,
                'video': f'https://my.mail.ru/video/embed/{url_parsed2}'
            })
        
        else:
            break

    return list_urls_streams
